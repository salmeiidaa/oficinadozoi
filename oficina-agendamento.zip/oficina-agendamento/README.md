# 🚗 Sistema de Agendamento para Oficina Mecânica

Sistema web completo para agendamento de serviços automotivos com interface para clientes e painel administrativo.

## 📋 Funcionalidades

### Para Clientes
- ✅ Formulário intuitivo em 4 etapas
- ✅ Informação de dados pessoais (nome, telefone)
- ✅ Cadastro do veículo (marca, modelo, ano, placa)
- ✅ Descrição detalhada do problema
- ✅ Seleção visual de data e horário disponíveis
- ✅ Confirmação de agendamento

### Para o Dono da Oficina
- ✅ Dashboard completo com todos os agendamentos
- ✅ Estatísticas em tempo real (total, pendentes, confirmados, cancelados)
- ✅ Filtros por status e data
- ✅ Visualização detalhada de cada agendamento
- ✅ Confirmação/cancelamento de agendamentos
- ✅ Informações completas do cliente e veículo

### Notificações (Para Implementar)
- 📧 Email automático para o dono quando há novo agendamento
- 📱 WhatsApp para confirmar com o cliente

## 🛠️ Tecnologias Utilizadas

- **Frontend**: React 18 + Vite
- **Roteamento**: React Router DOM
- **Backend**: Firebase (Firestore Database)
- **Estilização**: CSS puro com design moderno
- **Ícones**: Lucide React
- **Deploy**: Vercel (recomendado)

## 🚀 Instalação e Configuração

### 1. Pré-requisitos
- Node.js 16+ instalado
- Conta no Firebase (gratuita)
- Editor de código (VS Code recomendado)

### 2. Clone ou baixe o projeto
```bash
# Se estiver usando Git
git clone [url-do-repositorio]
cd oficina-agendamento

# Ou simplesmente baixe e extraia a pasta
```

### 3. Instale as dependências
```bash
npm install
```

### 4. Configure o Firebase

#### a) Crie um projeto no Firebase
1. Acesse https://console.firebase.google.com/
2. Clique em "Adicionar projeto"
3. Dê um nome (ex: "oficina-agendamento")
4. Desative o Google Analytics (não é necessário)
5. Clique em "Criar projeto"

#### b) Configure o Firestore Database
1. No menu lateral, clique em "Firestore Database"
2. Clique em "Criar banco de dados"
3. Escolha o modo de produção (você pode ajustar as regras depois)
4. Escolha a região mais próxima (southamerica-east1 para Brasil)

#### c) Configure as regras de segurança
No Firestore, vá em "Regras" e substitua por:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Permite leitura e escrita na coleção de agendamentos
    match /agendamentos/{agendamento} {
      allow read, write: true;
    }
  }
}
```

**⚠️ IMPORTANTE**: Essas regras são básicas para desenvolvimento. Para produção, você deve implementar autenticação e regras mais restritivas!

#### d) Obtenha as credenciais
1. Clique no ícone de engrenagem > "Configurações do projeto"
2. Role até "Seus aplicativos" > "Web"
3. Clique no ícone `</>`
4. Registre o app (dê um nome)
5. Copie as credenciais do `firebaseConfig`

#### e) Adicione as credenciais no projeto
Abra o arquivo `src/firebase/config.js` e substitua:

```javascript
const firebaseConfig = {
  apiKey: "sua-api-key-aqui",
  authDomain: "seu-projeto.firebaseapp.com",
  projectId: "seu-projeto-id",
  storageBucket: "seu-projeto.appspot.com",
  messagingSenderId: "123456789",
  appId: "seu-app-id"
};
```

### 5. Execute o projeto localmente
```bash
npm run dev
```

O sistema estará disponível em: `http://localhost:5173`

## 📱 Acessando as Páginas

### Página do Cliente (Agendamento)
```
http://localhost:5173/
```

### Painel do Dono (Dashboard)
```
http://localhost:5173/admin
```

## 🌐 Deploy na Vercel (GRATUITO)

### 1. Crie uma conta na Vercel
- Acesse https://vercel.com
- Faça login com GitHub, GitLab ou email

### 2. Deploy pelo Terminal (Método Mais Rápido)

```bash
# Instale a CLI da Vercel globalmente
npm install -g vercel

# Na pasta do projeto, execute:
vercel

# Siga as instruções:
# - Set up and deploy? Y
# - Which scope? Escolha sua conta
# - Link to existing project? N
# - Project name? oficina-agendamento (ou outro)
# - In which directory is your code located? ./
# - Want to override settings? N

# Deploy de produção
vercel --prod
```

### 3. Deploy pela Interface Web

1. Acesse https://vercel.com/new
2. Importe seu repositório Git ou faça upload da pasta
3. Configure:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. Clique em "Deploy"

### 4. Variáveis de Ambiente (Opcional - Mais Seguro)

Para produção, é recomendado usar variáveis de ambiente:

1. Na Vercel, vá em Settings > Environment Variables
2. Adicione cada variável do Firebase:
   ```
   VITE_FIREBASE_API_KEY=sua-api-key
   VITE_FIREBASE_AUTH_DOMAIN=seu-projeto.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=seu-projeto-id
   VITE_FIREBASE_STORAGE_BUCKET=seu-projeto.appspot.com
   VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
   VITE_FIREBASE_APP_ID=seu-app-id
   ```

3. Atualize `src/firebase/config.js`:
```javascript
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};
```

## 📧 Implementando Notificações

### Opção 1: EmailJS (Email Gratuito)

1. Crie conta em https://www.emailjs.com/
2. Configure um serviço de email
3. Crie um template de email
4. Instale a biblioteca:
```bash
npm install @emailjs/browser
```

5. Use no `agendamentosService.js`:
```javascript
import emailjs from '@emailjs/browser';

emailjs.send('service_id', 'template_id', {
  to_email: 'dono@oficina.com',
  cliente_nome: agendamento.nomeCliente,
  // ... outros dados
}, 'sua_public_key');
```

### Opção 2: WhatsApp (Evolution API - Gratuito)

1. Configure uma instância da Evolution API
2. Ou use serviços como Twilio (pago)
3. Integre via fetch/axios

## 🔐 Segurança para Produção

### Proteger o Dashboard Admin

Atualmente `/admin` está aberto. Para proteger:

1. Instale Firebase Auth:
```bash
npm install firebase
```

2. Configure autenticação no Firebase Console
3. Adicione proteção de rota no React Router
4. Implemente login antes de acessar `/admin`

### Regras do Firestore Mais Seguras

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /agendamentos/{agendamento} {
      // Clientes podem criar
      allow create: if request.auth == null;
      // Apenas admin autenticado pode ler/atualizar
      allow read, update, delete: if request.auth != null;
    }
  }
}
```

## 📊 Estrutura do Projeto

```
oficina-agendamento/
├── src/
│   ├── components/
│   │   ├── AgendamentoCliente.jsx    # Formulário de agendamento
│   │   ├── AgendamentoCliente.css
│   │   ├── DashboardDono.jsx         # Painel admin
│   │   └── DashboardDono.css
│   ├── firebase/
│   │   ├── config.js                 # Configuração Firebase
│   │   └── agendamentosService.js    # Funções CRUD
│   ├── App.jsx                       # Componente principal
│   ├── App.css
│   └── main.jsx
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## 🎨 Personalizações

### Alterar Cores

Edite os gradientes nos arquivos CSS:
- Cliente: `AgendamentoCliente.css` (linha 6)
- Dashboard: `DashboardDono.css` (várias linhas)

### Adicionar Mecânicos

No futuro, você pode adicionar:
1. Coleção de mecânicos no Firestore
2. Campo de seleção de mecânico no formulário
3. Filtro por mecânico no dashboard

### Horários Personalizados

Edite em `AgendamentoCliente.jsx` (linha 26):
```javascript
const horariosDisponiveis = [
  '08:00', '09:00', // ... seus horários
];
```

## 🐛 Solução de Problemas

### Erro ao iniciar: "Cannot find module"
```bash
rm -rf node_modules package-lock.json
npm install
```

### Erro no Firebase: "permission-denied"
- Verifique as regras do Firestore
- Certifique-se de que a coleção se chama "agendamentos"

### Build falha na Vercel
- Verifique se todas as variáveis de ambiente estão configuradas
- Confirme que `vite.config.js` está correto

## 📝 Próximos Passos

- [ ] Implementar autenticação para admin
- [ ] Adicionar notificações por email/WhatsApp
- [ ] Sistema de confirmação de presença
- [ ] Histórico de serviços do cliente
- [ ] Cadastro de mecânicos
- [ ] Relatórios e estatísticas avançadas
- [ ] Sistema de avaliação pós-atendimento

## 💰 Custos

- **Firebase**: Gratuito até 50k leituras/dia
- **Vercel**: Gratuito para projetos pessoais
- **EmailJS**: Gratuito até 200 emails/mês
- **Total**: R$ 0,00 para começar!

## 📞 Suporte

Em caso de dúvidas:
1. Consulte a documentação do Firebase
2. Verifique os logs no console do navegador (F12)
3. Revise as configurações do `firebase/config.js`

---

**Desenvolvido com ❤️ para facilitar o dia a dia das oficinas mecânicas**
