# 🚀 GUIA RÁPIDO - COMEÇAR EM 5 MINUTOS

## 1️⃣ Instalar Dependências
```bash
npm install
```

## 2️⃣ Configurar Firebase

### Criar Projeto
1. Acesse: https://console.firebase.google.com/
2. Clique em "Adicionar projeto"
3. Nome: "oficina-agendamento" (ou outro)
4. Desative Google Analytics
5. Clique em "Criar projeto"

### Ativar Firestore
1. Menu lateral > "Firestore Database"
2. "Criar banco de dados"
3. Modo: Produção
4. Região: southamerica-east1 (São Paulo)

### Configurar Regras (TEMPORÁRIO - para testes)
Na aba "Regras" do Firestore, cole:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /agendamentos/{agendamento} {
      allow read, write: true;
    }
  }
}
```

### Obter Credenciais
1. Ícone de engrenagem > "Configurações do projeto"
2. "Seus aplicativos" > Ícone Web `</>`
3. Nome do app: "oficina-web"
4. Copie o `firebaseConfig`

### Colar no Projeto
Abra `src/firebase/config.js` e substitua:
```javascript
const firebaseConfig = {
  apiKey: "cole-aqui",
  authDomain: "cole-aqui",
  projectId: "cole-aqui",
  storageBucket: "cole-aqui",
  messagingSenderId: "cole-aqui",
  appId: "cole-aqui"
};
```

## 3️⃣ Executar
```bash
npm run dev
```

## 4️⃣ Acessar

**Cliente (Agendamento):**  
http://localhost:5173/

**Admin (Dashboard):**  
http://localhost:5173/admin

## 5️⃣ Deploy GRATUITO na Vercel

```bash
# Instalar CLI
npm install -g vercel

# Deploy
vercel

# Deploy de produção
vercel --prod
```

Ou acesse: https://vercel.com/new e faça upload da pasta

---

## ⚠️ IMPORTANTE para PRODUÇÃO

### Proteger Dashboard
- Adicione autenticação Firebase Auth
- Configure proteção de rotas
- Atualize regras do Firestore

### Regras Firestore Seguras
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /agendamentos/{agendamento} {
      allow create: if request.auth == null;
      allow read, update, delete: if request.auth != null;
    }
  }
}
```

---

## 📱 Próximos Passos Opcionais

1. **Notificações por Email**
   - Cadastre-se em https://www.emailjs.com/
   - Configure template
   - Adicione código no `agendamentosService.js`

2. **WhatsApp**
   - Configure Evolution API
   - Ou use Twilio

3. **Personalizar**
   - Altere cores nos arquivos CSS
   - Adicione logo da oficina
   - Ajuste horários disponíveis

---

**Pronto! Seu sistema está rodando! 🎉**
